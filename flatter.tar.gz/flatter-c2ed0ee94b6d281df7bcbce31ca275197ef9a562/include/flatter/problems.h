#pragma once

#include "problems/lattice_reduction.h"
#include "problems/matrix_multiplication.h"
#include "problems/qr_factorization.h"
#include "problems/relative_size_reduction.h"
#include "problems/size_reduction.h"